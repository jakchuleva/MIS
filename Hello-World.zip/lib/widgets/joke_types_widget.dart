import 'package:flutter/material.dart';

class JokeTypes extends StatefulWidget {
  final List<String> jokeTypes;
  const JokeTypes({super.key, required this.jokeTypes});

  @override
  State<JokeTypes> createState() => _JokeTypesState();
}

class _JokeTypesState extends State<JokeTypes> {
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
        itemCount: widget.jokeTypes.length,
        itemBuilder: (context, index) {
          return Card(
            child: ListTile(
              title: Text(widget.jokeTypes[index]),
              onTap: () {
                Navigator.pushNamed(context, '/joke_types',
                    arguments: widget.jokeTypes[index]);
              },
            ),
          );
        });
  }
}
