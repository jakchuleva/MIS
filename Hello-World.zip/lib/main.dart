import 'package:flutter/material.dart';

import 'screens/home.dart';
import 'screens/jokes.dart';
import 'screens/random_joke.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Jokes App',
      initialRoute: '/',
      routes: {
        '/': (context) => const Home(),
        '/joke_types': (context) => const JokeTypes(),
        '/random_joke': (context) => const RandomJoke(),
      },
    );
  }
}
