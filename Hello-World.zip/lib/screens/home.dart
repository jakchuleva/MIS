import 'package:flutter/material.dart';

import '../services/api_service.dart';
import '../widgets/joke_types_widget.dart';

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  List<String> jokeTypes = [];

  @override
  void initState() {
    super.initState();
    getTypes();
  }

  void getTypes() async {
    final response = await ApiService.getTypes();
    setState(() {
      jokeTypes = response;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.purple[100],
          leading: IconButton(
            icon: const Icon(Icons.star),
            onPressed: () {
              Navigator.pushNamed(context, '/random_joke');
            },
          ),
          title: const Text("Jokes"),
        ),
        body: JokeTypes(jokeTypes: jokeTypes));
  }
}
