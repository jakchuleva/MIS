import 'package:flutter/material.dart';

import '../models/joke.dart';
import '../services/api_service.dart';

class JokeTypes extends StatefulWidget {
  const JokeTypes({Key? key}) : super(key: key);

  @override
  State<JokeTypes> createState() => _JokeTypesState();
}

class _JokeTypesState extends State<JokeTypes> {
  String type = '';

  @override
  Widget build(BuildContext context) {
    final String type = ModalRoute.of(context)!.settings.arguments as String;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.purple[100],
        title: Text('$type Jokes'),
      ),
      body: FutureBuilder<List<Joke>>(
          future: ApiService.getJokesByType(type),
          builder: (context, snapshot) {
            final jokes = snapshot.data!;
            return ListView.builder(
              itemCount: jokes.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(jokes[index].setup),
                  subtitle: Text(jokes[index].punchline),
                );
              },
            );
          }),
    );
  }
}
